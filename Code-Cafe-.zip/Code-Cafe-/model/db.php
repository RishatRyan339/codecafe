<?php 


function conn(){
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "code_cafe";
    
    $con = new mysqli($servername, $username, $password, $dbname);
   
    if ($con->connect_error) {
        die("Connection failed: " . $con->connect_error);
    }


    return $con;
}




?>


