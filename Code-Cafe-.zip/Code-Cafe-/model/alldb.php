<?php
require_once('db.php');

function auth($email, $password) {
    $con = conn();

    // Prepare the SQL statement to prevent SQL injection
    $stmt = $con->prepare("SELECT Password FROM member WHERE Email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 1) {
        $stmt->bind_result($hashed_password);
        $stmt->fetch();

        // Verify the password against the hashed password stored in the database
        if (password_verify($password, $hashed_password)) {
            return true;
        }
    }

    return false;
}

function register($email, $password) {
    $con = conn();
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Prepare the SQL statement to prevent SQL injection
    $stmt = $con->prepare("INSERT INTO member (Email, Password) VALUES (?, ?)");
    $stmt->bind_param("ss", $email, $hashed_password);

    if ($stmt->execute()) {
        return true;
    } else {
        return false;
    }
}
?>
