<?php
session_start();
require_once('../db.php'); // Adjust the path if needed

// Function to sanitize input
function sanitize_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve and sanitize form inputs
    $username = sanitize_input($_POST['username']);
    $phone = sanitize_input($_POST['phone']);
    $dob = sanitize_input($_POST['dob']);
    $email = sanitize_input($_POST['email']);
    $password = sanitize_input($_POST['password']);
    $confirm_password = sanitize_input($_POST['confirm_password']);

    // Validate inputs
    if (empty($username) || empty($phone) || empty($dob) || empty($email) || empty($password) || empty($confirm_password)) {
        $_SESSION['error'] = "All fields are required.";
        header("Location: registration.php");
        exit();
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['error'] = "Invalid email format.";
        header("Location: registration.php");
        exit();
    }

    if ($password !== $confirm_password) {
        $_SESSION['error'] = "Passwords do not match.";
        header("Location: registration.php");
        exit();
    }

    // Check if email already exists
    $con = conn();
    $stmt = $con->prepare("SELECT Email FROM member WHERE Email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $_SESSION['error'] = "Email already registered.";
        $stmt->close();
        $con->close();
        header("Location: registration.php");
        exit();
    }

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Insert new user into the database
    $stmt = $con->prepare("INSERT INTO member (Username, Phone, Dob, Email, Password) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $username, $phone, $dob, $email, $hashed_password);

    if ($stmt->execute()) {
        $_SESSION['success'] = "Registration successful! Please log in.";
        header("Location: login.php");
    } else {
        $_SESSION['error'] = "Error: " . $stmt->error;
        header("Location: registration.php");
    }

    $stmt->close();
    $con->close();
} else {
    // Not a POST request
    header("Location: registration.php");
    exit();
}
?>
